package main

import (
	"github.com/streadway/amqp"
	"encoding/json"
	"log"
	"fmt"
)

type Product struct {
	ID 			int		`json:"id"`
	Name 		string	`json:"product_name"`
	Quantity 	int		`json:"qty"`
	Price	 	int		`json:"price"`
}

func main(){
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
		if err != nil {
			log.Fatal(err)
		}
		defer conn.Close()

		ch, err := conn.Channel()
		if err != nil {
			log.Fatal(err)
		}
		defer ch.Close()

		q, err := ch.QueueDeclare(
			"order-product", // name
			false,   // durable
			false,   // delete when unused
			false,   // exclusive
			false,   // no-wait
			nil,     // arguments
		)
		if err != nil {
			log.Fatal(err)
		}

		msg, err := ch.Consume(
			q.Name,
			"",
			true,
			false,
			false,
			false,
			nil,
		)
		if err != nil {
			log.Fatal(err)
		}

		forever := make(chan bool)
		go func(){
			for d := range msg{
				var product Product
				err := json.Unmarshal(d.Body, &product)
				if err != nil {
					log.Printf("error while decoding %s", err)
					continue
				}
				SendMail(product)
			}
		}()

		fmt.Println("Que Consumed")
		fmt.Println("Waiting for event")
		<-forever
}

func SendMail(product Product){
	log.Printf("Product %s success", product.Name)
}