package main

import (
	"github.com/labstack/echo/v4"
	"net/http"
	"github.com/streadway/amqp"
	"encoding/json"
	"log"
)


type Product struct {
	ID 			int		`json:"id"`
	Name 		string	`json:"product_name"`
	Quantity 	int		`json:"qty"`
	Price	 	int		`json:"price"`
}

// {
// 	"id" 			: 1,
// 	"product_name"	: "",
// 	"qty"			: 1,
// 	"price"			: 1,
// }

func sendNotif(ch *amqp.Channel, queName string, product *Product) error {
	body, err := json.Marshal(product)
	if err != nil{
		return err
	}
	err = ch.Publish(
		"",
		queName,
		false,
		false,
		amqp.Publishing {
			ContentType: "application/json",
			Body:        body,
		  })
	if err != nil{
			return err
	}
	log.Printf("send notification for order : %s", product.Name)
	return nil
}

func main(){
	e := echo.New()

	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
		if err != nil {
			log.Fatal(err)
		}
		defer conn.Close()

		ch, err := conn.Channel()
		if err != nil {
			log.Fatal(err)
		}
		defer ch.Close()

		q, err := ch.QueueDeclare(
			"order-product", // name
			false,   // durable
			false,   // delete when unused
			false,   // exclusive
			false,   // no-wait
			nil,     // arguments
		)
		if err != nil {
			log.Fatal(err)
		}


		e.POST("/order", func(c echo.Context) error{
		productData := new(Product)
		err := c.Bind(productData)
		if err != nil {
			return c.JSON(http.StatusBadRequest, map[string]string{"error":"Invalid Bad Request"})
		}

		

		err = sendNotif(ch, q.Name, productData)
		if err != nil {
			return c.JSON(http.StatusBadRequest, map[string]string{"error":"Send Notification Failed"})
		}
		return c.JSON(http.StatusOK, map[string]string{"message":"Order product successfully"})
	})

	e.Logger.Fatal(e.Start(":8080"))
}